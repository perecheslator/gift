from .default import router

__all__ = [
    "router"
]