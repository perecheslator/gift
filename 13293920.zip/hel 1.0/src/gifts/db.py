import sqlite3 as s


def check_gift(id):
	with s.connect('src/gifts/db.db') as db:
		c = db.cursor()
		return c.execute('SELECT * FROM gifts WHERE id = ?', (id, )).fetchall()[0][1]

def change_text(text):
	with s.connect('src/gifts/db.db') as db:
		c = db.cursor()
		if text is None:
			pass
		else:c.execute('UPDATE config SET text = ?', (text, ))
		check = c.execute('SELECT * FROM config').fetchall()[0][0]

		return check

#src/gifts/